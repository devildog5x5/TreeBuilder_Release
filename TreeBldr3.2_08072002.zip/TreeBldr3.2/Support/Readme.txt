Tree Builder Version 3.1.0
Written by: Robert Foster

Latest features and fixes:
Added the ability to specify a Custom Context to add users from User Set 1 to.
Added the ability to select a Custom or pre-built LDIF file.
Fixed a problem where, if you selected a directory (working dir or user dir) you would get an invlaid path error because the path was missing a backslash "\". Added +"\" to sbuffer.

Scope: This Program is intended for internal use ONLY.

Features:
Fast, Easy, LDAP (Novell Directory Services) Tree and user creation via LDIF (Lightweight Directory Interface File) and LDAP (Lightweight Directory Access Protocol), including user home directories.

While basic operation and use is simple, more complex abilities have been added so that you get full feature operation by making a few changes.

Tree Builder Version 3.1.0 is a culmination of several programs (Tree Builder, User Set Builder, RICE and User Builder).

May be installed or Un-Installed rapidly, or it may be run from the support directory once extracted.

Instructions for Use:

Modify BOLDED items as needed and select the "Run Update" button.

1 - IP Address of LDAP Server (ie; 137.65.103.1)
2 - LDAP Port (636 is the SSL default, 389 is the non-SSL port)
3 - User Name (ie; .admin.context or a user with directory create rights).
4 - Password for the above user.
5 - RootCert.der file, you do not need the Novell client on your machine to run this but you do need to get the RootCert.der file, this can be done using a browser or copying it to diskette as well as a drive mapping and then browsing to it.
6 - Number of Users to Create - The number is limited only by time and sys volume space to contain  NDS.
7 - Select Version of NDS. This program supports NDS 7 and NDS 8.
8 - Select the "Run Update" button.
You are done. If you selected a large number of users it may take awhile to create them although it shouldn't take any longer than any other method.

If you have questions about any of the other features, I can be contacted at:
ext. 12449 or robert_foster@novell.com
